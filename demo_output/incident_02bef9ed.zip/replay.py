
import json
import argparse
import sys
from pathlib import Path
# Placeholder for user model import. User will need to modify or we wrap their model.
# For this demo, we assume they just want to see the data and metrics.

def main():
    parser = argparse.ArgumentParser(description="Replay VIRK incident")
    parser.add_argument("--incident", default="manifest.json", help="Path to incident manifest")
    args = parser.parse_args()
    
    manifest_path = Path(args.incident)
    if not manifest_path.exists():
        print(f"Error: {manifest_path} not found.")
        sys.exit(1)
        
    with open(manifest_path, 'r') as f:
        data = json.load(f)
        
    print(f"Replaying Incident: {data['incident_id']}")
    print(f"Timestamp: {data['timestamp']}")
    print("-" * 30)
    
    print("Drift Detected:", data['drift_profile']['is_drift_detected'])
    print("Magnitude:", data['drift_profile']['drift_magnitude'])
    
    print("-" * 30)
    print("Shift Fingerprint (Probable Causes):")
    for cause, score in data['fingerprint']['shift_types'].items():
        if score > 0.01:
            print(f"  - {cause}: {score:.2f}")
            
    print("-" * 30)
    print("Top Contributing Slices:")
    for sl in data['top_slices']:
        print(f"  - {sl['slice_name']}: {sl['contribution_score']:.2f}")
        
    print("-" * 30)
    print(f"Images available in 'images/' directory. Total: {len(data['affected_samples'])}")

if __name__ == "__main__":
    main()
